package Entity;

public class PersonExpense {
    private String email;
    private double amount;
}
