package Services;

public interface BillServiceInterface {

}
