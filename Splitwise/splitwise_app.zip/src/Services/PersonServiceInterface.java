package Services;

public interface PersonServiceInterface {
    void addUser(String username, String email);
}
